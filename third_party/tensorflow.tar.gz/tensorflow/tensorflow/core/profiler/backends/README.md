This directory contains subclasses of `tensorflow::profiler::ProfilerInterface`
and related code.

`tensorflow::ProfilerSession` manages a collection of profile sources. Each
profile source implements a subclass of
`tensorflow::profiler::ProfilerInterface`.
