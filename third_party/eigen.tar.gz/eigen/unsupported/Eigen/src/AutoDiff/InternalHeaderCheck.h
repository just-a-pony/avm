#ifndef EIGEN_AUTODIFF_MODULE_H
#error "Please include unsupported/Eigen/AutoDiff instead of including headers inside the src directory directly."
#endif
